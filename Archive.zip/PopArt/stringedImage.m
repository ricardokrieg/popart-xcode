//
//  stringedImage.m
//  PopsArt
//
//  Created by Bruno Garelli on 9/12/15.
//  Copyright © 2015 Netronian Inc. All rights reserved.
//

#import "stringedImage.h"

@implementation stringedImage

@end
